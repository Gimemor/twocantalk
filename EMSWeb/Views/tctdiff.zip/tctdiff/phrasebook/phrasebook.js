﻿class PhrasebookController {
    constructor(phrasebookDefinition) {
        this.phrasebookDefinition = phrasebookDefinition;

        // todo move modal control out of this controller
        this.isModal = !!phrasebookDefinition.phrasebookModalId
    }
    get phrasebookTreeId() { return '#' + this.phrasebookDefinition.phrasebookTreeId; }
    get phrasebookModalId() { return '#' + this.phrasebookDefinition.phrasebookModalId; }
    get deleteButtonId() { return '#' + this.phrasebookDefinition.deleteButtonId; }
    get addPhraseButtonId() { return '#' + this.phrasebookDefinition.addPhraseButtonId; }
    get addCategoryButtonId() { return '#' + this.phrasebookDefinition.addCategoryButtonId; }
    get modifyButtonId() { return '#' + this.phrasebookDefinition.modifyButtonId; }
   
    parseTree(rawTree) {
        if (!rawTree) {
            return;
        }
        const root = {
            selectedIcon: "glyphicon glyphicon-stop",
            text: rawTree.name,
            selectable: false,
            list: true,
            id: rawTree.id,
            state: {
                expanded: false,
            },
        };
        root.nodes = []
        if (rawTree.childLists.length > 0) {
            root.nodes = root.nodes.concat(rawTree.childLists.map(child => this.parseTree(child)));
        }
        if (rawTree.phrases.length > 0) {
            root.nodes = root.nodes.concat(rawTree.phrases.map(phrase => {
                return {
                    text: phrase.content,
                    id: phrase.id
                }
            }));
        }
        if (root.nodes.length == 0) {
            root.nodes = undefined;
            root.icon = 'fa fa-folder-open-o';
        }

        return root;
    }


    setTree = (rawTree) => {
        if (rawTree.length == 0) {
            alert('Phrasebook is empty');
            return;
        }

        this.tree = this.parseTree(rawTree);
        $(this.phrasebookTreeId).treeview({
            data: this.tree.nodes,
            collapseIcon: 'fa fa-minus',
            checkedIcon: 'fa fa-check-square-o',
            uncheckedIcon: 'fa fa-square-o',
            expandIcon: 'fa fa-plus',
            showCheckbox: true
        });
        $('.bstreeview .list-group-item').on('click', (event) => {
        })
        $(this.phrasebookTreeId).on('nodeSelected', (event, data) => {
            // close modal
            if (this.isModal) {
                $(this.phrasebookModalId).modal('hide');
            }
            this.phraseSelected.next(data.text);
        });
        let handleButtonState = (event, data) => {
            let selectedData = $(this.phrasebookTreeId).treeview('getEnabled').filter(x => x.state.checked)
            $(this.deleteButtonId).prop('disabled', selectedData.length === 0);
            $(this.modifyButtonId).prop('disabled', selectedData.length === 0 || selectedData.length > 1);
        }
        $(this.phrasebookTreeId).on('nodeChecked', handleButtonState);
        $(this.phrasebookTreeId).on('nodeUnchecked', handleButtonState);
        if (this.isModal) {
            $(this.phrasebookModalId).modal({});
        }
        $(this.phrasebookTreeId).trigger('nodeChecked');
    }

    showPhrasebook = (languageId) => {
        // Do something to each element here.
        getTree(languageId).done((rawTree) => this.setTree(rawTree));
        $(this.deleteButtonId).on('click', (evt) => {
            evt.preventDefault();
            const arrayIds = $(this.phrasebookTreeId).treeview('getEnabled').filter(x => x.state.checked)
                .map(x => { return { id: x.id, isList: !!x.list } });
            deletePhrases(arrayIds);
            getTree(languageId).done((rawTree) => this.setTree(rawTree));
        });

        $(this.addPhraseButtonId).on('click', (evt) => {
            evt.preventDefault();
            const arrayIds = $(this.phrasebookTreeId).treeview('getEnabled').filter(x => x.state.checked && x.list)
                .map(x => { return { id: x.id, isList: !!x.list } });
            let parentId;
            if (arrayIds.length == 0) {
                parentId = 0;
            } else if (arrayIds.length > 0) {
                parentId = arrayIds[0].id;
            } else {
                alert('Please, select the only category to be parent for a new phrase');
                return;
            }

            DayPilot.Modal.prompt('Enter the text:', { theme: "modal_rounded" }).then((result) => {
                var text = result.result;
                if (!text) {
                    return;
                }

                createPhrase(text, parentId);
                getTree(languageId).done((rawTree) => {
                    this.setTree(rawTree);
                    $(this.phrasebookTreeId).treeview('expandNode', [parentId ]);
                });
            });
        });


        $(this.addCategoryButtonId).on('click', (evt) => {
            evt.preventDefault();
            const arrayIds = $(this.phrasebookTreeId).treeview('getEnabled').filter(x => x.state.checked && x.list)
                .map(x => { return { id: x.id, isList: !!x.list } });
            let parentId = 0;

            DayPilot.Modal.prompt('Enter the name:', { theme: "modal_rounded" }).then((result) => {
                var text = result.result;
                if (!text) {
                    return;
                }
                createCategory(text, parentId);
                getTree(languageId).done((rawTree) => {
                    this.setTree(rawTree);
                    $(this.phrasebookTreeId).treeview('expandNode', [parentId ]);
                });
            });
        });


        $(this.modifyButtonId).on('click', (evt) => {
            evt.preventDefault();
            const arrayIds = $(this.phrasebookTreeId).treeview('getEnabled').filter(x => x.state.checked)
                .map(x => { return { id: x.id, isList: !!x.list } });
            let id = 0;
            if (arrayIds.length == 1) {
                id = arrayIds[0].id;
            } else {
                alert('Please, select the only node to be edited');
                return;
            }

            DayPilot.Modal.prompt('Enter the name:', { theme: "modal_rounded" }).then((result) => { 
                var text = result.result;
                if (!text) {
                    return;
                }
                const selection = $(this.phrasebookTreeId).treeview('getEnabled').filter(x => x.state.checked)[0]
                selection.text = text;
                modifyNode(text, id, arrayIds[0].isList);
                $(this.phrasebookTreeId).treeview('revealNode', [id, { silent: true }]);
            });
        });
    }
    phraseSelected = new rxjs.Subject();
}

function initPhrasebook(phrasebookDefinition) {
    return new PhrasebookController(phrasebookDefinition);
}